import sqlite3
import faker


def create_table(db):
    c = db.cursor()
    c.execute('''
    
                CREATE TABLE lego_sets(
                    setName varchar(30),
                    setId int,
                    setTheme varchar(30),
                    price varchar(30), 
                    uvp varchar(30),
                    discount float,
                    date date,
                    shop varchar(30),
                    id INTEGER PRIMARY KEY
                );
    ''')

    db.commit()

if __name__ == '__main__':
    db = sqlite3.connect('lego.db')

    create_table(db)


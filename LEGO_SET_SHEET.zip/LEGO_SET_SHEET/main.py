from tkinter import *
from tkinter import ttk
from search_from_web import get_details
import sqlite3




root = Tk()
root.title('LEGO SET SHEET')
# root.iconbitmap('/home/chris/Codes/LEGO_SET_SHEET/lego.png')
root.geometry('1300x600')

tree = ttk.Treeview(root)
global count


# define columns
tree['columns'] = ("Name", "ID", "Theme", "Price", "UVP", "Discount", "Date", "Shop")#, "PublYear", "EOL")

# format columns
tree.column("#0", width=0, stretch=NO)  # first column
tree.column("Name", anchor=CENTER, width=120, minwidth=25)
tree.column("ID", anchor=CENTER, width=80, minwidth=25)
tree.column("Theme", anchor=CENTER, width=124, minwidth=25)
tree.column("Price", anchor=CENTER, width=60, minwidth=25)
tree.column("UVP", anchor=CENTER, width=60, minwidth=25)
tree.column("Discount", anchor=CENTER, width=80, minwidth=25)
tree.column("Date", anchor=CENTER, width=90, minwidth=25)
tree.column("Shop", anchor=CENTER, width=90, minwidth=25)
#tree.column("PublYear", anchor=CENTER, width=90, minwidth=25)
#tree.column("EOL", width=50, minwidth=25)  ## maybe parent/child

# create headings
# # tree.heading("#0", text="No")
tree.heading("Name", text="Name")
tree.heading("ID", text="ID")
tree.heading("Theme", text="Theme")
tree.heading("Price", text="Price")
tree.heading("UVP", text="UVP")
tree.heading("Discount", text="Discount")
tree.heading("Date", text="Date")
tree.heading("Shop", text="Shop")
#tree.heading("PublYear", text="PublYear")
#tree.heading("EOL", text="EOL")

# Add data


tree.pack(pady=20)

win0 = Frame(root)
win0.pack(pady=20)

win = Frame(root)
win.pack()



################## ENTRY #########################

nameLabel = Label(win, text="Name")
nameLabel.grid(row=0, column=0)

idLabel = Label(win, text="ID")
idLabel.grid(row=0, column=1)

themeLabel = Label(win, text="Theme")
themeLabel.grid(row=0, column=2)

priceLabel = Label(win, text="Price")
priceLabel.grid(row=0, column=3)

ovpLabel = Label(win, text="UVP")  ## later auto!!
ovpLabel.grid(row=0, column=4)

dateLabel = Label(win, text="Date")
dateLabel.grid(row=0, column=5)

shopLabel = Label(win, text="Shop")
shopLabel.grid(row=0, column=6)

# entrybox

nameBox = Entry(win)
nameBox.grid(row=1, column=0)

iDBox = Entry(win)
iDBox.grid(row=1, column=1)
iDBox.config(width=10)

s_d = StringVar()
themeBox = OptionMenu(win, s_d, 'Harry Potter', 'Star Wars', 'Architecture', 'Creator', 'Ideas', 'BrickHeadz',
                      'Marvel', 'Ninjago', 'Jurassic World', 'Speed Champions', 'Minecraft', 'City', 'Others')
themeBox.grid(row=1, column=2)
themeBox.config(width=14)

priceBox = Entry(win)
priceBox.grid(row=1, column=3)
priceBox.config(width=10)

uvpBox = Entry(win)
uvpBox.grid(row=1, column=4)
uvpBox.config(width=10)

dateBox = Entry(win)
dateBox.grid(row=1, column=5)
dateBox.config(width=13)

shopBox = Entry(win)
shopBox.grid(row=1, column=6)
shopBox.config(width=13)


def calc_discount(price, uvp):
    if price and uvp:
        ######### komma-kontrolle #############
        if type(price) == str or type(uvp) == str:
            if price.find(','):
                price = price.replace(',', '.')
            if uvp.find(','):
                uvp = uvp.replace(',', '.')
            else:
                return 0
        #######################################
        price = float(price)
        uvp = float(uvp)
        return round(100 - (price / uvp * 100), 2)
    else:
        return 0


def get_records():
    global count
    cursor = db.cursor()
    cursor = cursor.execute('SELECT MAX(id) FROM lego_sets ')
    count = cursor.fetchone()[0]
    if not count: count = 0

    cursor.execute('SELECT * FROM lego_sets ORDER BY id;')
    for record in cursor.fetchall():
        print(record)
        tree.insert("",index='end',values=record)
        count += 1



def add_record():
    global count
    count += 1
    db.cursor()
    db.execute(f"""INSERT INTO lego_sets VALUES ("{nameBox.get()}", {iDBox.get()}, "{s_d.get()}", 
                                                "{str(priceBox.get()) + '€'}", "{str(uvpBox.get()) + '€'}",
                                                "{str(calc_discount(priceBox.get(), uvpBox.get())) + '%'}", 
                                                "{dateBox.get()}","{shopBox.get()}",{count}
                )""")
    db.commit()

    tree.insert(parent='', index='end', iid=count,
                text='',
                values=(
                    nameBox.get(), iDBox.get(), s_d.get(), str(priceBox.get()) + '€', str(uvpBox.get()) + '€',
                    str(calc_discount(priceBox.get(), uvpBox.get())) + '%', dateBox.get(),
                    shopBox.get()))
    nameBox.delete(0, END)
    iDBox.delete(0, END)
    priceBox.delete(0, END)
    uvpBox.delete(0, END)
    shopBox.delete(0, END)



def remove_one():
    x = tree.selection()[0]
    tree.delete(x)




def open_neuer_eintrag():
    top = Toplevel()
    top.title('Neuer Eintrag')

    win_top = Frame(top)
    win_top.pack(pady=20,anchor=W,padx=50)
    win_top0 = Frame(top)
    win_top0.pack()

    ################## Search #########################
    def search_set():
        my_dict = get_details(searchBox.get())
        print(my_dict)
        return my_dict

    searchLabel = Label(win_top, text="Set Suche:")
    searchLabel.grid(row=0, column=0)
    searchBox = Entry(win_top)
    searchBox.grid(row=0,column=1,padx=5)
    searchBox.config(width=8)
    searchButton = Button(win_top, text="Suche",command=search_set)
    searchButton.grid(row=1,column=0,columnspan=2,pady=4)



    ################## ENTRY #########################

    nameLabel = Label(win_top0, text="Name")
    nameLabel.grid(row=0, column=0)

    idLabel = Label(win_top0, text="ID")
    idLabel.grid(row=0, column=1)

    themeLabel = Label(win_top0, text="Theme")
    themeLabel.grid(row=0, column=2)

    priceLabel = Label(win_top0, text="Price")
    priceLabel.grid(row=0, column=3)

    ovpLabel = Label(win_top0, text="UVP")  ## later auto!!
    ovpLabel.grid(row=0, column=4)

    dateLabel = Label(win_top0, text="Date")
    dateLabel.grid(row=0, column=5)

    shopLabel = Label(win_top0, text="Shop")
    shopLabel.grid(row=0, column=6)

    # entrybox

    nameBox = Entry(win_top0)
    nameBox.grid(row=1, column=0)

    iDBox = Entry(win_top0)
    iDBox.grid(row=1, column=1)
    iDBox.config(width=10)

    s_d = StringVar()
    themeBox = OptionMenu(win_top0, s_d, 'Harry Potter', 'Star Wars', 'Architecture', 'Creator', 'Ideas', 'BrickHeadz',
                          'Marvel', 'Ninjago', 'Jurassic World', 'Speed Champions', 'Minecraft', 'City', 'Others')
    themeBox.grid(row=1, column=2)
    themeBox.config(width=14)

    priceBox = Entry(win_top0)
    priceBox.grid(row=1, column=3)
    priceBox.config(width=10)

    uvpBox = Entry(win_top0)
    uvpBox.grid(row=1, column=4)
    uvpBox.config(width=10)

    dateBox = Entry(win_top0)
    dateBox.grid(row=1, column=5)
    dateBox.config(width=13)

    shopBox = Entry(win_top0)
    shopBox.grid(row=1, column=6)
    shopBox.config(width=13)


def open_details():
    top = Toplevel()
    top.title('Details')


    win_top0 = Frame(top)
    win_top0.pack()


    ################## ENTRY #########################

    nameLabel = Label(win_top0, text="Name")
    nameLabel.grid(row=0, column=0)

    idLabel = Label(win_top0, text="ID")
    idLabel.grid(row=0, column=1)

    themeLabel = Label(win_top0, text="Theme")
    themeLabel.grid(row=0, column=2)

    priceLabel = Label(win_top0, text="Price")
    priceLabel.grid(row=0, column=3)

    ovpLabel = Label(win_top0, text="UVP")  ## later auto!!
    ovpLabel.grid(row=0, column=4)

    dateLabel = Label(win_top0, text="Date")
    dateLabel.grid(row=0, column=5)

    shopLabel = Label(win_top0, text="Shop")
    shopLabel.grid(row=0, column=6)

    # entrybox

    nameBox = Entry(win_top0)
    nameBox.grid(row=1, column=0)

    iDBox = Entry(win_top0)
    iDBox.grid(row=1, column=1)
    iDBox.config(width=10)

    s_d = StringVar()
    themeBox = OptionMenu(win_top0, s_d, 'Harry Potter', 'Star Wars', 'Architecture', 'Creator', 'Ideas', 'BrickHeadz',
                          'Marvel', 'Ninjago', 'Jurassic World', 'Speed Champions', 'Minecraft', 'City', 'Others')
    themeBox.grid(row=1, column=2)
    themeBox.config(width=14)

    priceBox = Entry(win_top0)
    priceBox.grid(row=1, column=3)
    priceBox.config(width=10)

    uvpBox = Entry(win_top0)
    uvpBox.grid(row=1, column=4)
    uvpBox.config(width=10)

    dateBox = Entry(win_top0)
    dateBox.grid(row=1, column=5)
    dateBox.config(width=13)

    shopBox = Entry(win_top0)
    shopBox.grid(row=1, column=6)
    shopBox.config(width=13)


def select_record():
    nameBox.delete(0,END)
    iDBox.delete(0, END)
    themeBox.delete(0, END)
    priceBox.delete(0, END)

    # grab record no
    selected = tree.focus()
    # grab value
    values = tree.item(selected, 'values')


    nameBox.insert(0,values[0])
    iDBox.insert(0, values[1])
    themeBox.insert(0, values[2])


def save_record():
    pass

######################### BUTTONS ###########################
select_button = Button(win0, text="Select Record", command=select_record)
select_button.grid(row=0,column=0,padx=5)

update_button = Button(win0, text="Save Record", command=save_record)
update_button.grid(row=0,column=1,padx=5)

addButton = Button(win0, text="Add Record", command=add_record)
addButton.grid(row=0,column=2,padx=5)


remove_one = Button(win0, text="Remove One", command=remove_one)
remove_one.grid(row=0,column=3,padx=5)


details = Button(win0, text="Neuer Eintrag", command=open_neuer_eintrag)
details.grid(row=0,column=4,padx=5)

details = Button(win0, text="details", command=open_details)
details.grid(row=0,column=5,padx=5)




#################### TOP-LEVEL-WINDOW ######################


if __name__ == '__main__':
    db = sqlite3.connect('lego.db')
    get_records()
    root.mainloop()

from  urllib import request

url = "https://www.lego.com/de-ch/search?q=10220"

try:
    response = request.urlopen(url)
    raw = response.read().decode('utf-8')
    print(raw)
except Exception as ex:
    print('Error:', ex)